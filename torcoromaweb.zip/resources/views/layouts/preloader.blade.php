<div class="preloader">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="lds-ring">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>
</div>
