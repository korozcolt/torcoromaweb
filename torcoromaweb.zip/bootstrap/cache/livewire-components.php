<?php return array (
  'chatbot-table' => 'App\\Http\\Livewire\\ChatbotTable',
  'support-table' => 'App\\Http\\Livewire\\SupportTable',
);