<div class="top-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-sm-6">
                <ul class="left-info">
                    <li>
                        <a href="mailto:<?php echo e($info->email ?? ''); ?>">
                            <i class='bx bxs-envelope'></i>
                            <?php echo e($info->email ?? ''); ?>

                        </a>
                    </li>
                    <li>
                        <a href="tel:<?php echo e($info->phone ?? ''); ?>">
                            <i class='bx bxs-phone-call'></i>
                            <?php echo e($info->phone ?? ''); ?>

                        </a>
                    </li>
                </ul>
            </div>

            <div class="col-lg-6 col-sm-6">
                <ul class="right-info">

                    <li>
                        <a href="<?php echo e($info->facebook ?? '#'); ?>" target="_blank">
                            <i class='bx bxl-facebook'></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e($info->twitter ?? '#'); ?>" target="_blank">
                            <i class='bx bxl-twitter'></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e($info->linkedin ?? '#'); ?>" target="_blank">
                            <i class='bx bxl-linkedin'></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e($info->instagram ?? '#'); ?>" target="_blank">
                            <i class='bx bxl-instagram'></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\torcoromaweb\resources\views/layouts/socialnetworks.blade.php ENDPATH**/ ?>