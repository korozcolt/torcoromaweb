<a href="/">
    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Torcoroma Logo" width="250">
</a>
<?php /**PATH C:\laragon\www\torcoromaweb\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>