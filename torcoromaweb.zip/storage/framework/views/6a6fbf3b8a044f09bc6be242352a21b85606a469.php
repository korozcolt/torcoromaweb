
<?php $__env->startSection('content-page'); ?>
    <!-- Page banner Area -->
    <div class="page-banner bg-1">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="page-content">
                        <h2>Acerca de</h2>
                        <ul>
                            <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                            <li>Torcoroma S.A.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page banner Area -->

    <!-- About Safe Area -->
    <div class="about-text-area ptb-100">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about-safe-text">
                        <h2>Solución segura, rápida y fácil para su transporte</h2>
                        <p>Siempre estamos en la busqueda constante del equilibrio entre la eficiencia y el buen servicio,
                            para llegar a contemplar y entregar lo mejor cada día. </p>
                    </div>

                    <div class="shipping-card">
                        <div class="shipping-contant">
                            <div class="shipping-sign">
                                <img src="<?php echo e(asset('img/sign.png')); ?>" alt="image">
                            </div>
                            <div class="shipping-image">
                                <img src="<?php echo e(asset('img/clients/client1.png')); ?>" alt="image">
                            </div>
                            <h3>Luis Assia</h3>
                            <span>SEO, Tocoroma S.A.</span>
                            <p>Tampoco hay nadie que ame o persiga o desee.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="safe-image">
                        <img src="<?php echo e(asset('images/about-page-main.jpg')); ?>" alt="image">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About Safe Area -->

    <!-- About Info -->
    <div class="about-info-area pb-70">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="about-info-card">
                        <h3>Nuestra Misión</h3>
                        <ul>
                            <li>
                                <i class='bx bx-check'></i>
                                Garantizar un optimo servicio de transporte terrestre de pasajeros en la modalidad basica
                                ccoriente y especial.
                            </li>
                            <li>
                                <i class='bx bx-check'></i>
                                Enfocado a la satisfacción de las necesidades y expectativas de sus asociados, clientes y
                                usuarios.
                            </li>
                            <li>
                                <i class='bx bx-check'></i>
                                Contribuir de manera activa al desarrollo sostenible de nuestra región con un servicio de
                                maxima calidad.
                            </li>
                            <li>
                                <i class='bx bx-check'></i>
                                Entregar todo a nuestro alcance para que nuestros usuarios y clientes se sientan
                                satisfechos.
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="about-info-card">
                        <h3>Nuestra Visión</h3>
                        <ul>
                            <li>
                                <i class='bx bx-check'></i>
                                Para 2022 ser una empresa que brinde a sus clientes y usuarios la mejor opción de tansporte
                                terrestre.
                            </li>
                            <li>
                                <i class='bx bx-check'></i>
                                Ademas, ser la mejor opción en modalidad de pasajeros basica, corriente y especial.
                            </li>
                            <li>
                                <i class='bx bx-check'></i>
                                Enfocados en la aplicación de estandares de calidad y seguridad que garantize oportunidad y
                                confort.
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 offset-md-3 offset-lg-0">
                    <div class="about-info-card">
                        <h3>Nuestros Principios</h3>
                        <ul>
                            <li>
                                <i class='bx bx-check'></i>
                                Somos personas honestas.
                            </li>
                            <li>
                                <i class='bx bx-check'></i>
                                Inspiramos confianza.
                            </li>
                            <li>
                                <i class='bx bx-check'></i>
                                Somos creativos.
                            </li>
                            <li>
                                <i class='bx bx-check'></i>
                                Nos relacionamos con respeto.
                            </li>
                            <li>
                                <i class='bx bx-check'></i>
                                Estamos comprometidos con el servicio.
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About Info -->

    <!-- Digital Area -->
    <div class="digital-area ptb-100">
        <div class="container">
            <div class="best-logistic-area ptb-100">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="logistic-text">
                                <h2>Conoce nuestra flota de buses</h2>
                                <p>At vero eos et et iusto odio ducimus qui blanditiis praesentium animi voluptatum deleniti atque corrupti dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</p>
                            </div>
                            <a href="#" class="default-btn-one">Read More</a>
                        </div>
                        <div class="col-lg-6">
                            <div class="logistic-image">
                                <img src="assets/img/services/services7.jpg" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="digital-top-contant">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="digital-image">
                            <img src="<?php echo e(asset('images/about-bottom.jpg')); ?>" alt="image">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="digital-text">
                            <h2>Prestando servicios de transporte desde <span>1953</span></h2>
                            <p>Enfocamos todos nuestros esfuerzos desde el principio para generar confianza y el mejor
                                servicio para todos nuestros clientes, entregando lo mejor.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="digital-card-contant">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="digital-card">
                            <div class="card-text">
                                <i class='bx bxs-bus'></i>
                                <h3><span>1953</span> - Aqui inicio todo</h3>
                                <p>Abrimos nuestras oficinas en Sincelejo, Sucre.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="digital-card">
                            <div class="card-text">
                                <i class='bx bx-map-alt'></i>
                                <h3><span>2004</span> - Ampliamos nuestra flota</h3>
                                <p>Le dimos nueva vida a nuestra flota de autobuses, creciendo significativamente.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="digital-card">
                            <div class="card-text">
                                <i class='bx bxs-truck'></i>
                                <h3><span>2008</span> - Ampliamos nuestra sede</h3>
                                <p>Crecimiento exponencial no hizo armar todo una gran estructura para mejorar la atencion.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="digital-card">
                            <div class="card-text">
                                <i class='bx bx-award'></i>
                                <h3><span><?php echo e(now()->year + 1); ?></span> - Este sera un año de prosperidad</h3>
                                <p>Contamos con la mejor disposicion para cada dia dar lo mejor y mejorar cada uno de
                                    nuestros servicios.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Digital Area -->

    <!-- partner Slider Area -->
    
    <!-- End partner Slider Area -->

    <!-- Newsletter Area -->
    
    <!-- End Newsletter Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\torcoromaweb\resources\views/pages/about.blade.php ENDPATH**/ ?>