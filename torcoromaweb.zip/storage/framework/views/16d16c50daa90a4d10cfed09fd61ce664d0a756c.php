<div class="preloader">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="lds-ring">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\torcoromaweb\resources\views/layouts/preloader.blade.php ENDPATH**/ ?>